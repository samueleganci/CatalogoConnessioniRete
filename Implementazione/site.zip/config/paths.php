<?php
    define('URL', 'http://localhost/');
?>