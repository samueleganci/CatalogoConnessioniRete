<?php
    define('URL', 'https://localhost/');
?>