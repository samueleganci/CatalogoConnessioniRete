<?php
class Admin extends Controller {
    public function __construct() {
        parent::__construct();
        Session::init();
        if(!Session::get('loggedIn')) {
            Session::destroy();
            header('location: ../index');
            exit;
        }else{
            if(Session::get('role') == 1) {
                header('location: ../../operator');
            }else if(Session::get('role') == 2) {
                header('location: ../../viewer');
            }
        }
    }

    function index() {
        $users = $this->model->showUsers();
        $this->view->render('admin/index', $users);
    }

    function modifyUser($user) {
        $userdata = $this->model->getUserData($user);
        $this->view->render('admin/modifyuser', $userdata);
    }

    function deleteUser($user) {
        $this->model->deleteUser($user);
    }

    function logout() {
        Session::destroy();
        header('location: ../../index');
        exit;
    }
}
?>