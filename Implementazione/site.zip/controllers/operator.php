<?php
class Operator extends Controller {
    public function __construct() {
        parent::__construct();
        Session::init();
        if(!Session::get('loggedIn')) {
            Session::destroy();
            header('location: ../index');
            exit;
        }else{
            if(Session::get('role') == 0) {
                header('location: ../../admin');
            }else if(Session::get('role') == 2) {
                header('location: ../../viewer');
            }
        }
    }

    function index() {
        
    }

    function logout() {
        Session::destroy();
        header('location: ../index');
        exit;
    }
}
?>