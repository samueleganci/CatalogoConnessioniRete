<?php
class Viewer extends Controller {
    public function __construct() {
        parent::__construct();
        Session::init();
        if(!Session::get('loggedIn')) {
            Session::destroy();
            header('location: ../index');
            exit;
        }else{
            if(Session::get('role') == 1) {
                header('location: ../../operator');
            }else if(Session::get('role') == 0) {
                header('location: ../../admin');
            }
        }
    }

    function index() {
        
    }

    function logout() {
        Session::destroy();
        header('location: ../index');
        exit;
    }
}
?>