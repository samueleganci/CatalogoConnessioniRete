<?php
    class Admin_Model extends Model {
        function __construct() {
            parent::__construct();
        }

        function showUsers() {
            $query = $this->db->prepare("SELECT * FROM utente, ruolo WHERE utente.ruolo_id = ruolo.id;");
            $query->execute();
            $users = $query->fetchAll();
            return $users;
        }

        function showCables() {
            $query = $this->db->prepare("SELECT * FROM cavo;");
            $query->execute();
            $cables = $query->fetchAll();
            return $cables;
        }

        function showDevices() {
            $query = $this->db->prepare("SELECT * FROM dispositivo;");
            $query->execute();
            $devices = $query->fetchAll();
            return $devices;
        }

        function deleteUser($user) {
            $query = $this->db->prepare("DELETE FROM utente WHERE nome = '$user';");
            $query->execute();
        }

        function deleteCable($cable) {
            $query = $this->db->prepare("DELETE FROM cavo WHERE id = '$cable';");
            $query->execute();
        }

        function deleteDevice($device) {
            $query = $this->db->prepare("DELETE FROM dispositivo WHERE id = '$device';");
            $query->execute();
        }

        function getUserData($user) {
            $query = $this->db->prepare("SELECT * FROM utente, ruolo WHERE utente.ruolo_id = ruolo.id AND utente.nome='$user';");
            $query->execute();
            $userdata = $query->fetchAll();
            return $userdata;
        }

        function getCableData($cable) {
            $query = $this->db->prepare("SELECT * FROM cavo WHERE id = '$cable';");
            $query->execute();
            $cabledata = $query->fetchAll();
            return $cabledata;
        }

        function getDeviceData($device) {
            $query = $this->db->prepare("SELECT * FROM dispositivo WHERE id ='$device';");
            $query->execute();
            $devicedata = $query->fetchAll();
            return $devicedata;
        }

        function changeUser($data) {
            $query = $this->db->prepare("UPDATE utente SET nome='$data[1]', password_utente=MD5('$data[2]'), ruolo_id='$data[3]' WHERE nome='$data[0]';");
            $query->execute();
        }

        function changeCable($data) {
            $query = $this->db->prepare("UPDATE cavo SET cavo='$data[1]' WHERE id='$data[0]';");
            $query->execute();
        }

        function changeDevice($data) {
            $query = $this->db->prepare("UPDATE dispositivo SET dispositivo='$data[1]' WHERE id='$data[0]';");
            $query->execute();
        }

        function newUser($data) {
            $query = $this->db->prepare("INSERT INTO utente (nome, password_utente, ruolo_id) VALUES ('$data[0]', MD5('$data[1]'), $data[2]);");
            $query->execute();
        }

        function newCable($data) {
            $query = $this->db->prepare("INSERT INTO cavo (cavo) VALUES ('$data[0]');");
            $query->execute();
        }

        function newDevice($data) {
            $query = $this->db->prepare("INSERT INTO dispositivo (dispositivo) VALUES ('$data[0]');");
            $query->execute();
        }
    }
?>