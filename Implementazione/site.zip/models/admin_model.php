<?php
    class Admin_Model extends Model {
        function __construct() {
            parent::__construct();
        }

        function showUsers() {
            $query = $this->db->prepare("SELECT * FROM utente, ruolo WHERE utente.ruolo_id = ruolo.id;");
            $query->execute();
            $users = $query->fetchAll();
            return $users;
        }

        function deleteUser($user) {
            $query = $this->db->prepare("DELETE FROM utente WHERE nome = '$user'");
            $query->execute();
            header("location: ../index");
        }

        function getUserData($user) {
            $query = $this->db->prepare("SELECT * FROM utente, ruolo WHERE utente.ruolo_id = ruolo.id AND utente.nome='$user';");
            $query->execute();
            $userdata = $query->fetchAll();
            return $userdata;
        }
    }
?>