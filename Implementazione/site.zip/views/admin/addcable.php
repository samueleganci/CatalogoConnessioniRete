<form class="col-12" method="post" action="<?php echo URL . "admin/newCable"; ?>">
  <div class="row">
    <div class="form-group col-sm-10">
      <label>Cavo</label>
      <input type="text" class="form-control" required name="cavo"/>
    </div>
    <input type="submit" class="btn btn-secondary col-sm-2" value="Aggiungi"/>
  </div>
</form>