<form class="col-12" method="post" action="<?php echo URL . "admin/newDevice"; ?>">
  <div class="row">
    <div class="form-group col-sm-4">
      <label>Dispositivo</label>
      <input type="text" class="form-control" required name="dispositivo"/>
    </div>
    <input type="submit" class="btn btn-secondary col-sm-1" value="Aggiungi"/>
  </div>
</form>