  <div class="col-2">
    <div class="nav flex-column nav-pills bg-dark" role="tablist" aria-orientation="vertical" style="height: 100%;">
      <a class="nav-link text-center" data-toggle="pill" role="tab" href="#">Utenti</a>
      <a class="nav-link text-center" data-toggle="pill" role="tab" href="#">Dispositivi</a>
      <a class="nav-link text-center" data-toggle="pill" role="tab" href="#">Cavi</a>
    </div>
  </div>
  <div class="col-8">
    <table>
      <tr>
        <th>Nome Utente</th>
        <th>Password</th>
        <th>Ruolo</th>
        <th></th>
        <th></th>
      </tr>
        <?php for($i = 0; $i < count($data); $i++) { ?>
          <tr>
            <td><?php echo $data[$i][0]; ?></td>
            <td><?php echo $data[$i][1]; ?></td>
            <td><?php echo $data[$i][4]; ?></td>
            <td><a href=<?php echo URL . "admin/modifyUser/" . $data[$i][0]; ?>>Modifica</a></td>
            <td><a href=<?php echo URL . "admin/deleteUser/" . $data[$i][0]; ?>>Elimina</a></td>
          </tr>     
        <?php } ?>
    </table>
  </div>
  <div class="col-2">
    <div class="nav bar-dark flex-column nav-pills bg-dark" role="tablist" aria-orientation="vertical" style="height: 100%;;">
      <a class="nav-link text-center" data-toggle="pill" role="tab" href="#">Aggiungi utente</a>
    </div>
  </div>