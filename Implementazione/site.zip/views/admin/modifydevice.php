<form class="col-12" method="post" action="<?php echo URL . "admin/changeDevice"; ?>">
  <input type="hidden" value="<?php echo $data[0][0]; ?>" name="idDispositivo">
  <p style="text-align: center;">Modifica del dispositivo: <?php echo $data[0][1]; ?></p>
  <div class="row">
    <div class="form-group col-sm-4">
      <label>Dispositivo</label>
      <input type="text" class="form-control" value="<?php echo $data[0][1]; ?>" required name="dispositivo"/>
    </div>
    <input type="submit" class="btn btn-secondary col-sm-1" value="Modifica"/>
  </div>
</form>
