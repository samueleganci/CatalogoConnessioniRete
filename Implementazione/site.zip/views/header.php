<!doctype html>
<html>

<head>
  <title>Gestionale</title>
  <link href="views/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/popper.min.js"></script>
  <script src="views/bootstrap/jquery.min.js"></script>
</head>

<body>
  <?php Session::init(); ?>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-brand"><?php echo Session::get('user'); ?></div>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo URL; ?>dashboard/logout">Logout</a></li>
      </ul>
    </div>
  </nav>

  <div id="content">